<template>
  <main class="content">
    <div class="container">
      <router-view></router-view>
    </div>
  </main>
</template>

<script>
export default {
  components: {},
};
</script>